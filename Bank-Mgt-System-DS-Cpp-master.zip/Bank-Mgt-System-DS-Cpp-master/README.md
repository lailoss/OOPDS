![](https://github.com/LOL-32/Bank-Mgt-System-DS-Cpp/blob/master/Bank%20Management%20System%20-%20DS.png)

# **Bank Management System - Data Structures**

### **Language** : C++

### **Description** :


   Demo (video Link)  : https://www.youtube.com/watch?v=Myn-1rIixgg


### **To Run this Code** :

    * Just Install Cpp Compiler 
    * Run "Untitled1.cpp" file 😊
